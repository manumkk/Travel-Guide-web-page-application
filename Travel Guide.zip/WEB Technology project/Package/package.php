<?php
$host="localhost";
$dbuser="root";
$password="";
$dbname="voyage";
$conn=mysqli_connect($host,$dbuser,$password,$dbname);
if(mysqli_connect_errno())
{
    die("Connection lost");
}
else{
    $packagename=$_POST['packagename'];
    $NAME=$_POST['NAME'];
    $EMAIL=$_POST['EMAIL'];
    $phone=$_POST['phone'];
    $checkin=$_POST['checkin'];
    $Room=$_POST['Room'];
    $child=$_POST['child'];
    $adult=$_POST['adult'];


    $sql="INSERT INTO booking(packagename,NAME,EMAIL,phone,checkin,Room,child,adult)
		values('$packagename','$NAME','$EMAIL','$phone','$checkin','$Room','$child','$adult')";
    if($conn->query($sql)){

        $message = "Package is Booked sucessfully";
        echo "<script type='text/javascript'>alert('$message');</script>";
        echo "<script> window.location.assign('http://localhost:63342/index.html/Package/package.html'); </script>";


    }
    else
    {
        echo "Error".$sql."<br>".$conn->error;
    }
    $conn->close();

}