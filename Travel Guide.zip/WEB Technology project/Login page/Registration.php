<html>
<head><title>Signup</title><link rel="shortcut icon" href="https://logopond.com/logos/211d9c927ce358e20581c624b74aaae1.png"></head>
<body>
<?php
session_start();
$host="localhost";
$dbuser="root";
$password="";
$dbname="voyage";
$conn=mysqli_connect($host,$dbuser,$password,$dbname);
if(mysqli_connect_errno())
{
    die("Connection lost");
}
else
{

    $Name=$_POST["name"];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $repassword=$_POST['repassword'];
    $check = "SELECT * from signup where email='$_POST[email]'";
    $lala = mysqli_query($conn, $check);
    $data = mysqli_fetch_array($lala, MYSQLI_NUM);
    if(empty($Name)||empty($email)||empty($password)||empty($repassword))
    {
        echo "Oops! can't leave any field blank";
    }
    else if($password!=$repassword)
    {
        echo("Oops! password do not match");
    }
    else if($data[0] > 0)
    {
        echo "ALREADY REGISTERED";
    }
    else
    {
        echo "<p style='text-align:center;font-size:50px;'>"."Successfully Registered"."</p>";
        echo "<script> window.location.assign('http://localhost:63342/WEB%20Technology%20project/Login%20page/Login.html'); </script>";

        $sql="insert into signup(name,email,password)"."values('$Name','$email','$password')";
        $repasswordes=mysqli_query($conn,$sql);
    }
}
?>
</body>
</html>
