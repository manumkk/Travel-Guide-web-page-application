<?php
$username=$_POST['username'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$message=$_POST['message'];
if(!empty($username)||!empty($email)||!empty($phone)||!empty($message))
{
    $host="localhost";
    $dbUsername="root";
    $dbPassword="";
    $dbname="voyage";

    $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname);
    if(mysqli_connect_error()){
        die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
    }
    else{

        $sql="INSERT INTO contactus(username,email,phone,message)
		values('$username','$email','$phone','$message')";

        if($conn->query($sql)){

            $message = " message is send sucessfully";
            echo "<script type='text/javascript'>alert('$message');</script>";
            echo "<script> window.location.assign('http://localhost:63342/index.html/Contact/Contact.html'); </script>";

        }
        else
        {
            echo "Error".$sql."<br>".$conn->error;
        }
        $conn->close();

    }
}
?>