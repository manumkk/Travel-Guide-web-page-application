<?php
$host="localhost";
$dbuser="root";
$password="";
$dbname="voyage";
$conn=mysqli_connect($host,$dbuser,$password,$dbname);
if(mysqli_connect_errno())
{
    die("Connection lost");
}
else{

    $Name=$_POST['Name'];
    $Email=$_POST['Email'];
    $phone=$_POST['phone'];
    $checkedin=$_POST['checkedin'];;
    $checkout=$_POST['checkout'];;
    $room=$_POST['room'];
    $hotel=$_POST['hotel'];

    if($hotel==1){
        $hotel="Ragamaya Resort Munnar";
    }
    else if($hotel==2){
        $hotel="Parakkat Nature Hotel & Resorts";
    }
    else if($hotel==3){
        $hotel="Greenwood Resort";
    }
    else if($hotel==4){
        $hotel="Hyatt Regency Thrissur";
    }
    else if($hotel==5){
        $hotel="Vembanad Lake Resort";
    }
    else if($hotel==6){
        $hotel="Forest glade Resort";
    }
    else if($hotel==7){
        $hotel="The World Backwaters";
    }
    else{
        $hotel="Sea Hut Homestay";
    }
    $sql="INSERT INTO hbooking(Name,Email,phone,checkedin,checkout,room,hotel)
		values('$Name','$Email','$phone','$checkedin','$checkout','$room','$hotel')";
    if($conn->query($sql)){

        $message = "Hotel is Booked sucessfully";
        echo "<script type='text/javascript'>alert('$message');</script>";
        echo "<script> window.location.assign('http://localhost:63342/index.html/Hotel/Hotel.html'); </script>";



    }
    else
    {
        echo "Error".$sql."<br>".$conn->error;
    }
    $conn->close();
}
?>